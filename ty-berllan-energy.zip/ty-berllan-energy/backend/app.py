# File: backend/app.py
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Dummy energy data
@app.route("/api/overview")
def get_energy_data():
    return jsonify({
        "battery_percentage": 76,
        "solar_generation": 4.2,
        "grid_import": 1.8,
        "home_consumption": 3.5,
        "eddi_heating": True
    })

# Dummy weather data
@app.route("/api/weather")
def get_weather():
    location = request.args.get("location", "NP18 2")
    return jsonify({
        "description": "Partly Cloudy",
        "temp": 17.6,
        "wind_speed": 3.9
    })

if __name__ == "__main__":
    app.run(debug=True)
